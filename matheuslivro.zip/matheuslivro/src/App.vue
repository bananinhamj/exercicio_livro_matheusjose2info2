<script>
import MenuLateral from "@/components/MenuLateral.vue";
export default {
  components: { MenuLateral },
};
</script>
<template>
  <MenuLateral />
  <header id="header">Cabeçalho</header>
  <main id="content">Principal</main>
  <footer id="footer">Rodapé</footer>
</template>
<style></style>
