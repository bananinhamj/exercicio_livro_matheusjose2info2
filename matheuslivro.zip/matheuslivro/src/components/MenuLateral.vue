<script>
export default {};
</script>
<template>
  <aside id="sidenav">
    <ul>
      <li>Perfil</li>
      <li>Livros</li>
      <li>Cadastro de Livros</li>
      <li>Vendas</li>
      <li>Configurações</li>
    </ul>
  </aside>
</template>
<style></style>
