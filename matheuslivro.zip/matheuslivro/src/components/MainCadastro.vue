<template>
  <main>
    <div class="principal">
      <h1>Cadastro de Livros</h1>
    </div>
  </main>
</template>
<style></style>
